<?php
session_start();
date_default_timezone_set("Asia/Seoul");
$id = $_SESSION[$_SERVER["REMOTE_ADDR"]];
$message=$_POST['message'];
$chatroom = $_POST['chatroom'];
$chatroome= base64_encode($chatroom);

@$db = new mysqli("localhost","root","skj21322","smutalk");
$query = "select name from membership_information where id='".$id."'";
$result = $db->query($query);
$row = $result->fetch_assoc();

if(strlen(trim($message))>0)
{	
	$query = "insert into ".$chatroom." values('".$id."','".$row['name']."','".$message."','".time()."')";
	$db->query($query);
}
header('location: http://localhost/chat.php?chatroom='.$chatroome);
?>