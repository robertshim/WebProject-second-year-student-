<!doctype html>
<html>
<head>
<title>Popup</title>
</head>
<body>
<?php
$str="이미 존재하는 ID입니다.";
$utf8 = iconv("UTF-8","EUC-KR",$str);

echo"$utf8";
?>
<body>