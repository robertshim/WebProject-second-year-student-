<!doctype html>
<html>
<head>
<title>Web smu talk에 오신 것을 환영합니다</title>
<meta charset="UTF-8"/>
<link rel="SHORTCUT ICON" href="favicon.ico">
</head>

<body bgcolor = " #e8e8e8">
<?php
	if(empty($_COOKIE['cookie']) == FALSE)
	{	
		header('location: http://localhost/afterlogin.php');
	}
?>
<image src="web_smu.png" style= "position : absolute; left:380px;">

<form method="post" action="loginConfirm.php">

<fieldset style="position : absolute; top:400px; left:432px; width:213px; height:70px; background-color:#FFFFFF;">
<input type="text" name="id" placeholder="계정" style="width:216px; height:30px" required></br>
<input type="password" name="password" placeholder="비밀번호"style="width:216px; height:30px" required>
</fieldset>

<div style="position : absolute; top: 500px; left:436px;">
	<input type="image" type ="submit" src="login.png">
	<a href="./signup.html"><image src="join.png"/></a>
</div>

</form>
</body>
</html>
