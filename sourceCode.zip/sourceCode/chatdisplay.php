<?php
session_start();
header("Pragma: no-cache");
header("Cache-control: no-store,no-cache,must-revalidate");
date_default_timezone_set("Asia/Seoul");
echo"<!doctype html>";
echo"<html>";
echo"<head>";
echo"<script language=\"javascript\"> window.setTimeout('window.location.reload()',1000);</script>";
echo"<meta charset=\"UTF-8\"/>";
echo"</head>";
echo"<body bgcolor = \"#9BBAD8\">";
$DOCUMENT_ROOT = $_SERVER['DOCUMENT_ROOT'];
$id = $_SESSION[$_SERVER["REMOTE_ADDR"]];
$chatroom = $_GET['chatroom'];
$chatroom = base64_decode($chatroom);
@$db = new mysqli("localhost","root","skj21322","smutalk");
	
$query = "select  *  from chat where chatroom='".$chatroom."'AND source='".$id."'";
$result = $db->query($query);
$chatinfo = $result->fetch_assoc();

$query = "select * from $chatroom where time >='".$chatinfo['participation']."'";
$result = $db->query($query);
$num_result = $result->num_rows;

for($i=0;$i<$num_result;$i++)
{	
	$row = $result->fetch_assoc();
	$message=$row['message'];
	$message =str_split($message);
	$len = count($message);
	$s=0;
	$k_count=0;
	$o_count=0;
	if($row['id'] == $id)	
	{
		while($len)
		{
			if(preg_match("/[\xA1-\xFE]/",$message[$s]))
			{
				$k_count++;				
				$s+=3;
				$len-=3;
			}
			else
			{
				$o_count++;
				$s+=1;
				$len-=1;
			}
		}
		$px= (($k_count * 12 + $o_count*7) +16 <180 ? ($k_count * 12) + ($o_count*7)+16: 180);
		$position = 330 - $px;
		echo"<div style=\"margin-left :".$position."px; width:".$px."px; border-radius:3px;background-color:#FFEC42;\">";
		echo"<p style=\"overflow:auto;padding:7px;  padding-bottom:9px; font-size:12px;\">".$row['message']."</p></div>";
	}
	else
	{
		while($len)
		{
			if(preg_match("/[\xA1-\xFE]/",$message[$s]))
			{
				$k_count++;
				$s+=3;
				$len-=3;
			}
			else
			{
				$o_count++;
				$s+=1;
				$len-=1;
			}
		}
		$px= (($k_count * 12 + $o_count*7) +16 <180 ? ($k_count * 12) + ($o_count*7)+16: 180);
		echo"<table>";
		echo "<tr><td><image src=\"profile.png\"></td>";
		echo"<td><p style=\"margin-bottom :8px; font-size:13px; font-weight : bold;\">".$row['name']."</p>";
		echo"<div style=\"width:".$px."px; border-radius:3px;background-color:white; float:right\">";
		echo"<p style=\" overflow:auto; margin:7px; margin-bottom:9px; font-size:12px;\">".$row['message']."</p></div></td>";
		echo "</tr></table>";
	}
}
echo"</body>";
echo"</html>";
?>