<?php
session_start();
?>

<!doctype html>
<html>
<head>
<title>Web smu talk</title>
<link rel="SHORTCUT ICON" href="favicon.ico">
<link rel="stylesheet" type="text/css" href="stylesheet.css">
<meta charset="UTF-8"/>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script>
var arr;
var arr2;
var j=0;
var tcount=0;
function makeflag(n){
	arr = new Array(n);
	arr2 = new Array(n);
	for(i=0;i<n;i++)
	{
		arr[i]=false;
	}
}
function friend(to){
	arr2[j++] = to;
}
function isclick(to,i)
{
	var id=document.getElementById(to);
	if(arr[i]==false)
	{	
		id.innerHTML="<image src=\"select_yes.png\" style=\"margin-left:11px; margin-top:5px;\">";
		$("#"+i+"").attr("bgcolor","#FFF173");
		arr[i]=true;
		tcount++;
	}
	else
	{
		id.innerHTML="<image src=\"select_no.png\" style=\" margin-left:10px; margin-top:4px;\">";
		$("#"+i+"").attr("bgcolor","white");
		arr[i]=false;
		tcount--;
	}
	if(tcount>0)
	{
		$("#submit").removeAttr("disabled");
	}
	else
	{
		$("#submit").attr("disabled","true");
	}
}
function issubmit(button,page){
	if(button == "submit")
	{
		var now = new Date();
		var url="findchatRoom.php?date="+now;
		j=1;
		for(i=0;i<arr.length;i++)
		{
			if(arr[i] == true)
			{
				if(j==1)
					url+="&to="+arr2[i];
				else
					url+="&to"+j+"="+arr2[i]
				j++;
			}
		}
		url+="&chatroom= "
		window.open(url);
	}
	window.location.href=page;
}
</script>
</head>
<body bgcolor = "#e8e8e8">
<table id="invitecontain">
<tr><td id="invitetitle"><center><p style="font-size:14px;">초대하기</p></center></td></tr>

<tr><td style="padding:0px; margin:0px;">
<div id="inviteselecttop"><center><input type="text" placeholder="이름검색" style=" margin-top: 5px; width: 262px; height:24px;"></div>
<div id="inviteselectbottom">
<div id="invitebox">
	<p class="mint "style="padding-top : 8px;" >친구</p>
</div>
<?php
$id = $_SESSION[$_SERVER["REMOTE_ADDR"]];
$url = $_SERVER['HTTP_REFERER'];
@$db = new mysqli("localhost","root","skj21322","smutalk");
$query = "select FriendId from Friend where id='".$id."'";
$result = $db->query($query);
$num_results = $result->num_rows;
echo  "<script> makeflag($num_results); </script>";
for($i=0; $i <$num_results; $i++)
{
	$row = $result->fetch_assoc();
	$query = "select id,name from membership_information where id='".$row['FriendId']."'";
	$FInfor = $db->query($query);
	$Frow = $FInfor->fetch_assoc();
	$to = base64_encode($row['FriendId']);
	echo"<script> friend('".$to."');</script>";
	echo"<table id=\"$i\"class=\"inviteprofile\" onclick=\"isclick('".$to."',$i);\">";
	echo "<tr><td><image src=\"profile.png\"></td>";
	echo "<td colspan=\"3\"><p align=\"left\">".$Frow['name']."</p></td><td id=\"$to\"><image src=\"select_no.png\" style=\" margin-left:10px; margin-top:4px;\"></td>";
	echo "</tr></table>";
}
echo"</div></td></tr>";
echo"<tr><td style=\"height:62px;\"><center><input id = \"submit\" onclick= \"issubmit('submit','".$url."');\" 
type=\"button\"  disabled=\"true\" value=\"확인\" style=\" background-color:#FFEC42; width:65px; height:35px; margin-right:5px;\">
<input type=\"button\" id=\"cancel\" value=\"취소\" onclick=\"issubmit('cancel','".$url."');\"style=\"width:65px; height:35px;margin-left:5px;\"></td></tr>";
?>
</table>
</body>
</html>