<!doctype html>
<html>
<head>
<title>Web smu talk에 오신 것을 환영합니다</title>
<link rel="SHORTCUT ICON" href="favicon.ico">
</head>
<body bgcolor="#e8e8e8">
<?php
$name = trim($_POST['name']);
$id = trim($_POST['id']);
$password=trim($_POST['password']);
$department=trim($_POST['department']);

@$db = new mysqli("localhost","root","skj21322","smutalk");
$query = "select * from membership_Information where id='".$id."'";
$result = $db->query($query);
$num_results = $result->num_rows;
if(!$num_results)
{	
	$query = "insert into membership_Information values('".$id."','".$password."','".$name."','".$department."')";
	$result = $db->query($query);
	header('location: http://localhost/Wellcome.php');
}
else
{	
	echo"<script>history.back()</script>";
	echo"<script> window.open(\"http://localhost/popup.php\",\"popup\",\"left=800,top=100, width=200,height=50\");</script>";
}
?>
</body>
</html>
