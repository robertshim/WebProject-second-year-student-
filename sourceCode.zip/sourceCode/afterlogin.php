<?php
session_start();
?>
<!doctype html>
<html>
<head>
<title>Web smu talk</title>
<link rel="SHORTCUT ICON" href="favicon.ico">
<link rel="stylesheet" type="text/css" href="stylesheet.css">
<meta charset="UTF-8"/>
<script>
function chat(to)
{
	var now = new Date();
	var url="findchatRoom.php?date="+now+"&to="+to;
	window.open(url);
}
</script>
</head>
<body bgcolor = "#e8e8e8">

<div id="contain" >
	<div id="bar">
		<p id="title">WebSmuTalk</p>
	</div>
	<div id="menu">
		<?php	
			$id = $_SESSION[$_SERVER["REMOTE_ADDR"]];
			echo"<image src=\"profile_button.png\" style=\"margin-left:10px;\">";
			echo"<a href=\"http://localhost/chatlist.php\"><image src=\"chat_button_close.png\" style=\"margin-left:16px; margin-bottom:2px;\"></a>";
			echo"<a href=\"http://localhost/searchfriend.php\"><image src=\"look_button_close.png\" style=\"margin-left:20px;\"></a>";
			echo"<a href=\"http://localhost/invite.php\"><image src=\"group.png\" style=\"position:absolute; top:39px;left:318px;\"></a>";
			echo"<a href=\"http://localhost/favorite.php\"><image src=\"favorite.png\" style=\"position:absolute; top:39px; left:285px;\"></a>";
		?>
	</div>
	<div id="search">
		<center><input type="text" placeholder="이름검색" style="margin-top : 8px; width: 328px;"></center>
	</div>
	
	<div id="frame">
	<div class="box">
		<p class="mint "style="padding-top : 8px;" >내 프로필</p>
	</div>
		<?php
			echo"<table class=\"profile1\">";
		
			$id = $_SESSION[$_SERVER["REMOTE_ADDR"]];
			@$db = new mysqli("localhost","root","skj21322","smutalk");
			$query = "select * from membership_information where id='".$id."'";
			$result = $db->query($query);
			$row = $result->fetch_assoc();
			
			echo "<tr><td><image src=\"profile.png\"></td>";
			echo "<td><p>".$row['name']."</p></td><td></td><td></td><td></td><td></td>";
			echo"</table>";
		
		$query = "select FriendId from Friend where id='".$id."' AND favorites=true";
		$result = $db->query($query);
		if($result)
		{
			$num_results = $result->num_rows;
			if($num_results)
			{
				echo"
				<div class=\"box\">
					<p class=\"mint \"style=\"padding-top : 8px;\" >즐겨찾기 $num_results</p>
				</div>";
			
				for($i=0; $i <$num_results; $i++)
				{
					$row = $result->fetch_assoc();
					$query = "select id,name,department from membership_information where id='".$row['FriendId']."'";
					$FInfor = $db->query($query);
					$Frow = $FInfor->fetch_assoc();
					$to = base64_encode($row['FriendId']);
					echo"<table class=\"profile1\" ondblclick=\"chat('".$to."');\">";
					echo "<tr><td><image src=\"profile.png\"></td>";
					echo "<td><p>".$Frow['name']."</p></td><td></td><td></td><td></td><td></td>";
					echo "</tr></table>";
				}	
		
			}
		}
		$query = "select FriendId from Friend where id='".$id."'";
		$result = $db->query($query);
		if($result)	
		{
			$num_results = $result->num_rows;
			if($num_results)
			{	echo"
				<div class=\"box\">
					<p class=\"mint \"style=\"padding-top : 8px;\" >친구 $num_results</p>
				</div>";
			
				for($i=0; $i <$num_results; $i++)
				{
					$row = $result->fetch_assoc();
					$query = "select id,name,department from membership_information where id='".$row['FriendId']."'";
					$FInfor = $db->query($query);
					$Frow = $FInfor->fetch_assoc();
					$to = base64_encode($row['FriendId']);
					echo"<table class=\"profile1\" ondblclick=\"chat('".$to."');\">";
					echo "<tr><td><image src=\"profile.png\"></td>";
					echo "<td><p>".$Frow['name']."</p></td><td></td><td></td><td></td><td></td>";
					echo "</tr></table>";
				}			
			}
		}
		?>
</div>
</body>
</html>