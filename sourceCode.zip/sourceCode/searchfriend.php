<?php
	session_start();
	header("Pragma: no-cache");
	header("Cache-control: no-store,no-cache,must-revalidate");
	echo"<!doctype html>";
	echo"<html>";
	echo"<head>";
	echo"<title>Web smu talk</title>";
	echo"<link rel=\"SHORTCUT ICON\" href=\"favicon.ico\">";
	echo"<link rel=\"stylesheet\" type=\"text/css\" href=\"stylesheet.css\">";
	echo"<meta charset=\"UTF-8\"/>";
	echo"</head>";
	echo"<body bgcolor = \"#e8e8e8\">";
	echo"<div id=\"contain\">";	
	echo"<div id=\"bar\">";
	echo"<p id=\"title\">WebSmuTalk</p>";
	echo"</div>";
	$id = $_SESSION[$_SERVER["REMOTE_ADDR"]];
	echo"<div id=\"menu\">";
	echo"<a href=\"http://localhost/afterlogin.php\"><image src=\"profile_button_close.png\" style=\"margin-left:10px;\"></a>";
	echo"<a href=\"http://localhost/chatlist.php\"><image src=\"chat_button_close.png\" style=\"margin-left:16px; margin-bottom:2px;\"></a>";
	echo"<image src=\"look_button.png\" style=\"margin-left:20px;\">";
	echo"<a href=\"http://localhost/invite.php\"><image src=\"group.png\" style=\"position:absolute; top:39px;left:318px;\"></a>";
	echo"</div>";
	echo"<div id=\"search\">";
	echo"<center><input type=\"text\" placeholder=\"스뮤톡ID\" style=\"margin-top : 8px; width: 328px;\"></center>";
	echo"</div>";
	echo"<div id=\"frame\">";
	echo"<div class=\"box\" name=\"display\">";
	echo"<p class=\"mint \"style=\"padding-top : 8px;\" >추천 친구</p>";
	echo"</div>";
	
		$arr = array();
		@$db = new mysqli("localhost","root","skj21322","smutalk");
		$query = "select department from membership_information where id='".$id."'";
		$result = $db->query($query);
		$row = $result->fetch_assoc();
		$query = "select id,name from membership_information where department='".$row['department']."'AND id<>'".$id."'";
		$member_result = $db->query($query);
		$num_member_results = $member_result->num_rows;
	
		$query = "select FriendId from Friend where id='".$id."'";
		$friend_result = $db->query($query);
		$num_friend_results = $friend_result->num_rows;
		
		for($i=0;$i<$num_friend_results; $i++)
		{
			$row = $friend_result->fetch_assoc();
			$arr[$i] = $row['FriendId'];
		}
		
		for($i=0; $i <$num_member_results; $i++)
		{
			$row = $member_result->fetch_assoc();
			
			for($j=0;$j<$num_friend_results;$j++)
			{
				if($arr[$j] == $row['id'])
				{	
					break;
				}
			}
			if($j==$num_friend_results)
			{	
				echo"<form action=\"addfriend.php\" method=\"post\">";
				echo"<input type=\"hidden\" name=\"FriendId\" value=\"".base64_encode($row['id'])."\">";
				echo"<table class=\"profile2\">";
				echo "<tr><td><image src=\"profile.png\"></td>";
				echo "<td><p>".$row['name']."</p></td><td></td><td></td><td></td>";
				echo "<td><input type=\"image\" type=\"submit\" onclick = \"window.location.reload(true);\" src=\"add_button.png\"></a></td>";
				echo "</tr></table>";
				echo "</form>";
			}
		}
		
echo"</div>";
echo"</div>";
echo"</body>";
echo"</html>";
?>