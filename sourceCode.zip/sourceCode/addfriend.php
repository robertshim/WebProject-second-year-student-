<?php
	session_start();
	$id = $_SESSION[$_SERVER["REMOTE_ADDR"]];
	$FriendId = $_POST['FriendId'];
	$FriendId = base64_decode($FriendId);
	@$db = new mysqli("localhost","root","skj21322","smutalk");
	
	$query = "select * from Friend where id='".$id."' AND FriendId='".$FriendId."'";
	$result = $db->query($query);
	$num_results = $result->num_rows;
	if($num_results)
	{	
		$row=$result->fetch_assoc();
		echo $row['favorites'];
		if(!$row['favorites'])
		{
			$query = "update Friend set favorites=1 where id='".$id."' AND FriendId='".$FriendId."'";
			$db->query($query);
		}
		else
		{
			$query = "update Friend set favorites=0 where id='".$id."' AND FriendId='".$FriendId."'";
			$db->query($query);
		}
		header('location: http://localhost/favorite.php');
	}
	else
	{
		$query = "insert into Friend values('".$id."','".$FriendId."',0)";	
		$result = $db->query($query);
		header('location: http://localhost/searchfriend.php');
	}
?>