<?php
session_start();
$id = trim($_POST['id']);
$password = trim($_POST['password']);
if(!$id || !$password)
{
	header('location: http://localhost/Wellcome.php');
	exit();
}

@$db = new mysqli("localhost","root","skj21322","smutalk");
$query = "select password from membership_Information where id='".$id."'";
$result = $db->query($query);
$num_results = $result->num_rows;


if(!$num_results)
{
	header('location: http://localhost/Wellcome.php');
	exit();
}
else
	$row = $result->fetch_assoc();

if($password == $row['password'])
{
	$_SESSION[$_SERVER["REMOTE_ADDR"]] = $id;
	setcookie("cookie","login","0","/");
	header('location: http://localhost/afterlogin.php');
}
else
{
	header('location: http://localhost/Wellcome.php');
}
?>