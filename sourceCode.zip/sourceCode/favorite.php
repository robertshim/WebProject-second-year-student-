<?php
session_start();
?>
<!doctype html>
<html>
<head>
<title>Web smu talk</title>
<link rel="SHORTCUT ICON" href="favicon.ico">
<link rel="stylesheet" type="text/css" href="stylesheet.css">
<meta charset="UTF-8"/>
<script>
</script>
</head>
<body bgcolor = "#e8e8e8">

<div id="contain" >
	<div id="bar">
		<p id="title">WebSmuTalk</p>
	</div>
	<div id="menu">
		<?php	
			$id = $_SESSION[$_SERVER["REMOTE_ADDR"]];
			echo"<image src=\"profile_button.png\" style=\"margin-left:10px;\">";
			echo"<a href=\"http://localhost/chatlist.php\"><image src=\"chat_button_close.png\" style=\"margin-left:16px; margin-bottom:2px;\"></a>";
			echo"<a href=\"http://localhost/searchfriend.php\"><image src=\"look_button_close.png\" style=\"margin-left:20px;\"></a>";
			echo"<a href=\"http://localhost/invite.php\"><image src=\"group.png\" style=\"position:absolute; top:39px;left:318px;\"></a>";
			echo"<a href=\"http://localhost/afterlogin.php\"><image src=\"favorite.png\" style=\"position:absolute; top:39px; left:285px;\"></a>";
		?>
	</div>
	<div id="frame2">
	<?php
		$id = $_SESSION[$_SERVER["REMOTE_ADDR"]];
		@$db = new mysqli("localhost","root","skj21322","smutalk");
		
		$query = "select FriendId from Friend where id='".$id."' AND favorites=true";
		$result = $db->query($query);
		if($result)
		{
			$num_results = $result->num_rows;
			if($num_results)
			{
				echo"
				<div class=\"box\">
					<p class=\"mint \"style=\"padding-top : 8px;\" >즐겨찾기 $num_results</p>
				</div>";
			
				for($i=0; $i <$num_results; $i++)
				{
					$row = $result->fetch_assoc();
					$query = "select name from membership_information where id='".$row['FriendId']."'";
					$FInfor = $db->query($query);
					$Frow = $FInfor->fetch_assoc();
					$to = base64_encode($row['FriendId']);
					echo"<form action=\"addfriend.php\" method=\"post\">";
					echo"<input type=\"hidden\" name=\"FriendId\" value=\"".$to."\">";
					echo"<table class=\"profile1\">";
					echo "<tr><td><image src=\"profile.png\"></td>";
					echo "<td><p>".$Frow['name']."</p></td><td></td><td></td><td></td>";
					echo "<td><input type=\"image\" type=\"submit\" onclick = \"window.location.reload(true);\" src=\"add_favorite_no.png\"></a></td>";
					echo "</tr></table></form>";
				}	
		
			}
		}
		$query = "select FriendId from Friend where id='".$id."' AND favorites=false";
		$result = $db->query($query);
		if($result)	
		{
			$num_results = $result->num_rows;
			if($num_results)
			{	echo"
				<div class=\"box\">
					<p class=\"mint \"style=\"padding-top : 8px;\" >친구 $num_results</p>
				</div>";
			
				for($i=0; $i <$num_results; $i++)
				{
					$row = $result->fetch_assoc();
					$query = "select name from membership_information where id='".$row['FriendId']."'";
					$FInfor = $db->query($query);
					$Frow = $FInfor->fetch_assoc();
					$to = base64_encode($row['FriendId']);
					echo"<form action=\"addfriend.php\" method=\"post\">";
					echo"<input type=\"hidden\" name=\"FriendId\" value=\"".$to."\">";
					echo"<table class=\"profile1\">";
					echo "<tr><td><image src=\"profile.png\"></td>";
					echo "<td><p>".$Frow['name']."</p></td><td></td><td></td><td></td>";
					echo "<td><input type=\"image\" type=\"submit\" onclick = \"window.location.reload(true);\" src=\"add_favorite.png\"></a></td>";
					echo "</tr></table></form>";
				}			
			}
		}
	?>
	</div>
</div>
</body>
</html>