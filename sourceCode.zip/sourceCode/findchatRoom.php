<?php
session_start();
date_default_timezone_set("Asia/Seoul");
$id = $_SESSION[$_SERVER["REMOTE_ADDR"]];
$date = $_GET['date'];
$date = explode("GMT",$date);
$date=strtotime($date[0]);
@$db = new mysqli("localhost","root","skj21322","smutalk");
if(count($_GET) <4)
{
	$FriendId= $_GET['to'];
	$FriendId=base64_decode($FriendId);
	
	$query = "select chatroom from chat where source='".$id."'AND destination='".$FriendId."'";
	$result = $db->query($query);
	$num_results = $result->num_rows;
	if(!$num_results)
	{
		$chatroom = $date."".$id;
		$query = "create table ".$chatroom."(id char(12) not null,name char(40),message char(255),time char(10))Default charset=utf8";
		$db->query($query);
		
		$query = "insert into chat values('".$id."','".$chatroom."','".$date."','".$FriendId."')";
		$db->query($query);
		
		$query = "insert into chat values('".$FriendId."','".$chatroom."','".$date."','".$id."')";
		$db->query($query);
		$chatroom = base64_encode($chatroom);
	}
	else
	{
		$row = $result->fetch_assoc();
		$chatroom = base64_encode($row['chatroom']);	
	}
	header('location: http://localhost/chat.php?chatroom='.$chatroom);
}
else
{
	$FriendId = array();
	$flag = false;
	$i=0;
	foreach($_GET as $value)
	{
		if($flag== false || $i==count($_GET))
		{	
			$flag = true;
			continue;
		}
		$value=base64_decode($value);
		$FriendId[$value] = $value;
	}
	if(empty($_GET['chatroom']))
	{	
		$chatroom = $date."".$id;
		$query = "create table ".$chatroom."(id char(12) not null,name char(40),message char(255),time char(10))Default charset=utf8";
		$db->query($query);
		
		$query = "insert into chat values('".$id."','".$chatroom."','".$date."','g')";
		$db->query($query);
		
		foreach($FriendId as $value)
		{
			$query = "insert into chat values('".$value."','".$chatroom."','".$date."','g')";
			$db->query($query);
		}
		$chatroom = base64_encode($chatroom);
		header('location: http://localhost/chat.php?chatroom='.$chatroom);
	}
	else
	{
		header('location: http://localhost/chat.php?chatroom='.$_GET['chatroom']);
	}	
}
?>