<?php
session_start();
?>
<!doctype html>
<html>
<head>
<title>Web smu talk</title>
<link rel="SHORTCUT ICON" href="favicon.ico">
<link rel="stylesheet" type="text/css" href="stylesheet.css">
<meta charset="UTF-8"/>
<script>
function check_byte(name,max)
{

   var current_str     = name.value; // 이벤트가 일어난 컨트롤의 value 값
   var current_str_len = current_str.length;  // 전체길이

   var li_max      = max; // 제한할 글자수 크기
   var i           = 0;  // for문에 사용
   var li_byte     = 0;  // 한글일경우는 2 그밗에는 1을 더함
   var li_len      = 0;  // substring하기 위해서 사용
   var chk_one_char = ""; // 한글자씩 검사한다
   var admit_str     = ""; // 글자수를 초과하면 제한할수 글자전까지만 보여준다.

   for(i=0; i< current_str_len; i++)
   {
      // 한글자추출
      chk_one_char = current_str.charAt(i);

      // 한글이면 2를 더한다.
      if (escape(chk_one_char).length > 4)
      {
         li_byte += 3;
      }
      // 그밗의 경우는 1을 더한다.
      else
      {
         li_byte++;
      }

      // 전체 크기가 li_max를 넘지않으면
      if(li_byte <= li_max)
      {
         li_len = i + 1;
      }
   }
   
   // 전체길이를 초과하면
   if(li_byte > li_max)
   {
      admit_str = current_str.substr(0, li_len);
      name.value = admit_str;
   }
   name.focus();   
}

function noEnter()
{
   if(event.keyCode == 13)
      event.returnValue=false;
}
</script>


</head>

<body bgcolor = "#e8e8e8">
<div id="chatcontain">
<div id="chattitle">

<?php
	$id=$_SESSION[$_SERVER["REMOTE_ADDR"]];
	$chatroomd = $_GET['chatroom'];
	$chatroom =base64_decode($chatroomd);
	@$db = new mysqli("localhost","root","skj21322","smutalk");
	$query = "select source from chat where chatroom='".$chatroom."'AND source<>'".$id."'";
	$Fresult = $db->query($query);
	$num_results = $Fresult->num_rows-1;
	$FriendId = $Fresult->fetch_assoc();
	
	$query = "select name from membership_information where id='".$FriendId['source']."'";
	$result = $db->query($query);
	$row = $result->fetch_assoc();
	$name=$row['name'];
	
	for($i=0;$i<$num_results;$i++)
	{
		$FriendId = $Fresult->fetch_assoc();
		$query = "select name from membership_information where id='".$FriendId['source']."'";
		$result = $db->query($query);
		$row = $result->fetch_assoc();
		$name=$name." ".$row['name'];
	}
	if($num_results>0)
		echo"<p style=\"font-size:13px; margin-left:10px; padding-top:10px;\">그룹채팅 - ".$name."</p>";	
	else
		echo"<p style=\"font-size:13px; margin-left:10px; padding-top:10px;\">".$row['name']."</p>";
?>
</div>
<div>
<?php
echo"<iframe src=\"chatdisplay.php?chatroom=".$chatroomd."\"  width=\"361px\" height=\"521px\" style=\" border:0px; padding-bottom:0px; overflow-x:hidden;\"></iframe>";
?>
</div>
<div id="chatactivity">
<form action="chatsave.php" method="post">
<?php
echo"<input type=\"hidden\" name=\"chatroom\" value=\"".$chatroom."\">";
?>
<table id="chatarea">
<tr>
<td style="padding-right:0px;"><textarea name="message"  autofocus onkeyup="check_byte(message,255);" onkeypress="noEnter();"></textarea></td> 
<td style="padding-left:0px;"><input type="submit" id="transmit" value="전송"></td>
</tr>
</div>
</div>
</body>
</html> 