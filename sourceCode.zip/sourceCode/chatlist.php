<?php
	session_start();
	header("Pragma: no-cache");
	header("Cache-control: no-store,no-cache,must-revalidate");
	date_default_timezone_set("Asia/Seoul");
	echo"<!doctype html>";
	echo"<html>";
	echo"<head>";
	echo"<title>Web smu talk</title>";
	echo"<link rel=\"SHORTCUT ICON\" href=\"favicon.ico\">";
	echo"<link rel=\"stylesheet\" type=\"text/css\" href=\"stylesheet.css\">";
	echo"<meta charset=\"UTF-8\"/>";
	echo"<script language=\"javascript\"> window.setTimeout('window.location.reload()',1000);</script>";
	echo "<script>
	function chat(to)
	{
	var now = new Date();
	var url=\"findchatRoom.php?date=\"+now+\"\"+to;
	window.open(url);
	}
	</script>";
	echo"</head>";
	echo"<body bgcolor = \"#e8e8e8\">";
	echo"<div id=\"contain\">";	
	echo"<div id=\"bar\">";
	echo"<p id=\"title\">WebSmuTalk</p>";
	echo"</div>";
	$id = $_SESSION[$_SERVER["REMOTE_ADDR"]];	
	echo"<div id=\"menu\">";
	echo"<a href=\"http://localhost/afterlogin.php\"><image src=\"profile_button_close.png\" style=\"margin-left:10px;\"></a>";
	echo"<image src=\"chat_button.png\" style=\"margin-left:16px; margin-bottom:2px;\"></a>";
	echo"<a href=\"http://localhost/searchfriend.php\"><image src=\"look_button_close.png\" style=\"margin-left:20px;\"></a>";
	echo"<a href=\"http://localhost/invite.php\"><image src=\"group.png\" style=\"position:absolute; top:39px;left:318px;\"></a>";
	echo"</div>";
	echo"<div id=\"frame2\">";
	@$db = new mysqli("localhost","root","skj21322","smutalk");
	$query = "select * from chat where source='".$id."'";
	$chatlist = $db->query($query);
	
	if($chatlist)
	{
		$num_chat = $chatlist->num_rows;
		for($i=0;$i<$num_chat;$i++)
		{
			$chatroom= $chatlist->fetch_assoc();

			$query = "select message,time from ".$chatroom['chatroom']." order by time desc limit 1";
			$result = $db->query($query);
			$num_result = $result->num_rows;
			if($num_result)
			{
				$message =$result->fetch_assoc();
				
				$query = "select source from chat where chatroom='".$chatroom['chatroom']."'AND source<>'".$id."'";
				$Fresult = $db->query($query);
				$num_result = $Fresult->num_rows-1;
				$FriendId = $Fresult->fetch_assoc();
				
				$query = "select name from membership_information where '".$FriendId['source']."'=id";
				$result = $db->query($query);
				$row = $result->fetch_assoc();
				$name = $row['name'];
				$to = base64_encode($FriendId['source']);
				$url = "&to=".$to;
				
				for($j=0;$j<$num_result;$j++)
				{				
					$FriendId = $Fresult->fetch_assoc();
					$query = "select name from membership_information where '".$FriendId['source']."'=id";
					$result = $db->query($query);
					$row = $result->fetch_assoc();	
					$name = $name.",".$row['name']; 
					$to = base64_encode($FriendId['source']);
					$url = $url."&to".$j."=".$to;
				}
				if($num_result >0)
				{
					$url = $url."&chatroom=".base64_encode($chatroom['chatroom']);
				}
				echo"<table class=\"chatbox\" ondblclick=\"chat('".$url."');\">";
				echo "<tr><td><image src=\"profile.png\"></td>";
				echo"<td colspan=\"4\"style=\"word-break:break-all;\"><p style=\"width :200px;overflow:hidden;margin-top :5px; font-size:12px; font-weight:bold;\">$name</p>";
				echo"<p style=\" width :200px; height:35px; overflow:hidden; margin:5px; margin-left:0px; margin-bottom:8px; font-size:12px;\">".$message['message']."</p></td>";
				if(date("Y-m-d",time()) == date("Y-m-d",$message['time']))
					echo"<td style=\"width:70px;\"><p align =\"right\" style=\" margin-right: 8px;margin-bottom:50px; font-size : 11px; color:lightgray;\"> ".date("a h:i",$message['time'])."</p></td>";
				else
					echo"<td style=\"width:70px;\"><p align =\"right\" style=\" margin-right: 8px;margin-bottom:50px; font-size : 11px; color:lightgray;\"> ".date("Y-m-d",$message['time'])."</p></td>";
				echo "</tr></table>";
			}
		}
	}
	echo"</div>";
	echo"</div>";
?>